﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2_Lista
{
    class Cliente
    {
        public string nome;
        public int codigo;
        public double salario;
    }
}
