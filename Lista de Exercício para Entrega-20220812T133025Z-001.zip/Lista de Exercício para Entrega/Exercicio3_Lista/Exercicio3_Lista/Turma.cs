﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio3_Lista
{
    class Turma
    {
        public string periodo;
        public int serie;
        public string sigla;
        public string tipo_de_ensino;
    }
}
